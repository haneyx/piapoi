SELECT 'DROP TABLE ' || table_name || ' CASCADE CONSTRAINTS;' 
FROM all_tables 
WHERE owner = 'PIAPOI';

SELECT 'DROP SEQUENCE ' || sequence_name || ';' 
FROM all_sequences 
WHERE sequence_owner = 'PIAPOI';


---- o usar forsozamente

BEGIN
   FOR rec IN (SELECT table_name FROM all_tables WHERE owner = 'PIAPOI') LOOP
      EXECUTE IMMEDIATE 'DROP TABLE PIAPOI.' || rec.table_name || ' CASCADE CONSTRAINTS';
   END LOOP;
END;
/

-- Eliminar todas las secuencias
BEGIN
   FOR rec IN (SELECT sequence_name FROM all_sequences WHERE sequence_owner = 'PIAPOI') LOOP
      EXECUTE IMMEDIATE 'DROP SEQUENCE PIAPOI.' || rec.sequence_name;
   END LOOP;
END;
/
