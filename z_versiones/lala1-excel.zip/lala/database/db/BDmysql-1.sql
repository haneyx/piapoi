CREATE DATABASE nombre_base_de_datos
CHARACTER SET utf8mb4
COLLATE utf8mb4_spanish_ci;

-- Tabla usuario
CREATE TABLE usuario(
    id      INT AUTO_INCREMENT PRIMARY KEY, 
    tipo	VARCHAR(1) NOT NULL,
    numera   INT NOT NULL,
    cargo	VARCHAR(100) NOT NULL,
    usuario	VARCHAR(50) NOT NULL,
    clave	VARCHAR(50) NOT NULL,
    redirige	VARCHAR(20) NOT NULL
);

-- Tabla pofi
CREATE TABLE pofi (
    id       INT AUTO_INCREMENT PRIMARY KEY, 
    numera   INT NOT NULL,
    color    INT DEFAULT 0 NOT NULL,
    codigo   VARCHAR(10) NOT NULL,
    pofi     VARCHAR(50) NOT NULL
);

-- Fondo financiero
CREATE TABLE fondo (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    codigo      VARCHAR(6) NOT NULL,
    fondo       VARCHAR(60) NOT NULL
);

-- OOCC
CREATE TABLE oocc (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    numera      INT NOT NULL,
    oficina     VARCHAR(80) NOT NULL
);

-- OODD
CREATE TABLE oodd (
    id          INT AUTO_INCREMENT PRIMARY KEY, 
    numera      INT NOT NULL,
    oodd        VARCHAR(50) NOT NULL
);

-- EESS
CREATE TABLE eess (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    id_oodd         INT NOT NULL,
    codigo          VARCHAR(10) NOT NULL,
    eess            VARCHAR(70) NOT NULL,
    FOREIGN KEY (id_oodd) REFERENCES oodd(id)
);

-- Cabeza OOCC
CREATE TABLE proyoocc (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    id_oocc             INT NOT NULL,
    codcentrocostos     VARCHAR(25) NOT NULL,
    centrogestor        VARCHAR(3) NOT NULL CHECK (centrogestor IN ('AFES','S')),
    codcentrogestor     CHAR(2) NOT NULL CHECK (codcentrogestor IN ('11','12')),
    actividadoperativa  VARCHAR(40) NOT NULL,
    cod_actividad_ope   VARCHAR(16) NOT NULL,
    prioridad           INT NOT NULL,
    bloquear            INT DEFAULT 0 NOT NULL,
    FOREIGN KEY (id_oocc) REFERENCES oocc(id)
);

-- Cabeza OODD
CREATE TABLE proyoodd (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    id_oodd         INT NOT NULL,
    id_eess         INT NOT NULL,
    cerrado         INT DEFAULT 0 NOT NULL,
    FOREIGN KEY (id_oodd) REFERENCES oodd(id),
    FOREIGN KEY (id_eess) REFERENCES eess(id)
);

-- Detalle
CREATE TABLE detalle (
    id             INT AUTO_INCREMENT PRIMARY KEY, 
    id_proyoocc    INT NULL,
    id_proyoodd    INT NULL,
    id_fondo       INT NULL, 
    id_pofi        INT NOT NULL,  
    tipo           INT DEFAULT 0 NULL,
    estimacion     INT DEFAULT 0 NOT NULL,
    enero          INT DEFAULT 0 NOT NULL,
    febrero        INT DEFAULT 0 NOT NULL,
    marzo          INT DEFAULT 0 NOT NULL,
    abril          INT DEFAULT 0 NOT NULL,
    mayo           INT DEFAULT 0 NOT NULL,
    junio          INT DEFAULT 0 NOT NULL,
    julio          INT DEFAULT 0 NOT NULL,
    agosto         INT DEFAULT 0 NOT NULL,
    septiembre     INT DEFAULT 0 NOT NULL,
    octubre        INT DEFAULT 0 NOT NULL,
    noviembre      INT DEFAULT 0 NOT NULL,
    diciembre      INT DEFAULT 0 NOT NULL,
    total2026      INT DEFAULT 0 NOT NULL,
    proy2027       INT DEFAULT 0 NOT NULL,
    proy2028       INT DEFAULT 0 NOT NULL,
    proy2029       INT DEFAULT 0 NOT NULL,
    FOREIGN KEY (id_proyoocc) REFERENCES proyoocc(id),
    FOREIGN KEY (id_proyoodd) REFERENCES proyoodd(id),
    FOREIGN KEY (id_fondo) REFERENCES fondo(id),
    FOREIGN KEY (id_pofi) REFERENCES pofi(id)
);

