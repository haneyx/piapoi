<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="IngHarold">
    <title>ORGANO DESCONCENTRADO</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/login.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div class="todo">
    <div class="container medio">
        <div id="tapa">
            <div id="retorna">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <button class="verbutton" type="submit">Salir</button>
                </form>
            </div>
            <div id="titulo"><?php echo e(session('redx')); ?></div>
            <!--div id="ver">
                <form action="<?php echo e(route('consolida_red')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <button class="verbutton" type="submit">Ver consolidado RED</button>
                </form>
            </div-->
        </div>
        <div class="largo">
            <form action="<?php echo e(route('ooddmain')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label for="establecimiento">Seleccione su Órgano Desconcentrado</label>
                <select name="ide_eess" id="ide_eess" required>
                    <?php $__currentLoopData = $eess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->codigo); ?> :: <?php echo e($item->eess); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="hidden" name="name_idex" id="name_idex">
            </div>
            <button type="submit">Continuar</button>
        </form>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\laragon\www\lala\resources\views/ooddselect.blade.php ENDPATH**/ ?>