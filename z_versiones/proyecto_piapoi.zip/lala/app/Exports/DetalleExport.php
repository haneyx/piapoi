<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;

class DetalleExport implements FromArray, WithHeadings, WithMapping
{
    protected $dataExportar;

    public function __construct($dataExportar)
    {
        $this->dataExportar = $dataExportar;
    }

    public function array(): array
    {
        // Este método retorna los datos tal cual los has recibido
        return $this->dataExportar;
    }

    public function headings(): array
    {
        // Agregar encabezados en la fila 12
        return [
            'Anexo 9',
            'Proyección Presupuestal 2026',
            '',
            'Órgano Desconcentrado: ' . session('redx'), // Aquí se coloca el valor de la sesión
            'Establecimiento de Salud: ' . session('esx'), // Aquí se coloca el valor de la sesión
            '',
            'Fondo Financiero', 'COD POFI', 'POSICIÓN PRESUPUESTARIA', 'TIPO GASTO',
            'ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SET', 'OCT', 'NOV', 'DIC', 'TOTAL 2026'
        ];
    }

    public function map($row): array
    {
        // Aquí mapeamos los valores en las columnas desde los datos exportados
        return [
            $row['financia_codigo'] ?? '',
            $row['pofi_codigo'] ?? '',
            $row['pofi'] ?? '',
            $row['tipo'] ?? '',
            $row['enero'] ?? 0,
            $row['febrero'] ?? 0,
            $row['marzo'] ?? 0,
            $row['abril'] ?? 0,
            $row['mayo'] ?? 0,
            $row['junio'] ?? 0,
            $row['julio'] ?? 0,
            $row['agosto'] ?? 0,
            $row['septiembre'] ?? 0,
            $row['octubre'] ?? 0,
            $row['noviembre'] ?? 0,
            $row['diciembre'] ?? 0,
            $row['total2026'] ?? 0,
        ];
    }
}