<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="IngHarold">
    <title>ORGANO DESCONCENTRADO</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/login.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div class="todo">
    <div class="container medio">
        <!-- Formulario para enviar el valor del select -->
        <form action="<?php echo e(route('ooddmain')); ?>" method="POST">
        <div id="tapa">
            <div id="retorna">
                <button class="verbutton" type="submit">Salir</button>
            </div>
            <div id="titulo"><?php echo e(session('ses_cargo')); ?></div>
            <div id="ver">
                <button class="verbutton" type="submit">Ver consolidado RED</button>
            </div>
        </div>
        <div class="largo">
        <label for="establecimiento">Seleccione su Órgano Desconcentrado</label>
            <?php echo csrf_field(); ?>  <!-- Asegúrate de incluir el token CSRF -->
            <select name="idex" id="idex" required>
                <?php $__currentLoopData = $eess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->codigo); ?> :: <?php echo e($item->eess); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input value="<?php echo e(session('ses_cargo')); ?>" type="hidden" name="red_idex" id="red_idex">
            <input type="hidden" name="name_idex" id="name_idex">
        </div>
        <button type="submit">Continuar</button>
        </form>
    </div>
</div>

<script>
document.getElementById("actix").addEventListener("change", function() {
    const selectedValue = this.value;

    // Si selecciona "Otras actividades", mostrar el menú flotante
    if (selectedValue === "3") {
        document.getElementById("extraOptions").style.display = "block"; // Muestra el menú flotante
    } else {
        // Si se selecciona cualquier otra opción, ocultar el menú flotante
        document.getElementById("extraOptions").style.display = "none";
    }
});

// Agregar opciones al select original cuando el ses hace clic en una opción del menú flotante
document.getElementById("additionalMenu").addEventListener("click", function(e) {
    if (e.target && e.target.nodeName === "LI") {
        // Obtener el valor de la opción seleccionada
        const optionText = e.target.textContent;
        const optionValue = e.target.getAttribute("data-value");

        // Agregar la nueva opción al select 'eessx'
        const select = document.getElementById("eessx");
        const newOption = document.createElement("option");
        newOption.value = optionValue;
        newOption.textContent = optionText;
        select.appendChild(newOption);
        
        // Ocultar el menú después de agregar la opción
        document.getElementById("extraOptions").style.display = "none";
    }
});


    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\lara\resources\views/ooddselect.blade.php ENDPATH**/ ?>