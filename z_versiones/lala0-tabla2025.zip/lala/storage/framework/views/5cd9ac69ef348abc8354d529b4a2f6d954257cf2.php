<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="IngHarold">
    <title>ORGANO DESCONCENTRADO</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/login.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<style>

.popup {
    display: none; /* El popup está oculto por defecto */
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
    justify-content: center;
    align-items: center;
}

.popup-content {
    background-color: white;
    padding: 20px;
    border-radius: 5px;
    width: 300px;
    text-align: center;
}

.close-btn {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 20px;
    cursor: pointer;
}


    </style>
<body>
<div class="todo">
    <div class="container largo">
            <div id="tapa">
                <div id="retorna">
                    <button class="verbutton" onclick="window.history.back()">Cambiar EESS</button>
                </div>
                <div id="titulo" style="margin-top: -10px;"><?php echo e(session('redx')); ?> <BR> <?php echo e(session('codesx')); ?>::<?php echo e(session('esx')); ?></div>
                <div id="ver">
                    <button class="verbutton" type="submit">Ver consolidado EESS</button>
                </div>
            </div>
            <div class="largo">
                <label class="medio1">Seleccione su actividad:</label>
                <label class="medio2">Prioridad:</label>
                <label class="medio3">Acciones</label>
            </div>

            <div class="largo1">
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="<?php echo e(route('ooddhoja')); ?>" method="POST">
                <div class="cuarto">
                    <input class="sel1" name="" id="" value="<?php echo e($result->actividad); ?>" readonly>
                    <input class="sel2" name="" id="" value="<?php echo e($result->prioridad); ?>" readonly>
                    <input type="hidden" name="cabezaidex" value="<?php echo e($result->cabeza_id); ?>">
                    <button class="but1" type="submit">Editar</button>
                    <button class="but2" type="submit">Cerrar</button>
                </div>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </div>


</div>

</body>
</html>
<?php /**PATH C:\laragon\www\lala\resources\views/ooddmain.blade.php ENDPATH**/ ?>