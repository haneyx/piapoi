<?php
namespace App\Http\Controllers;

use App\Models\Eess;
use App\Models\Oodd;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Log;

class CabezaController extends Controller
{
    public function ooddmain(Request $request)
    {
        Session::put('idesx',$request->input('ide_eess'));
        //fijar las variables de sesion
        $eess = DB::table('eess')
                    ->select('codigo', 'eess')
                    ->where('id', $request->input('ide_eess'))
                    ->limit(1)
                    ->first();

        Session::put('codesx',$eess->codigo);
        Session::put('esx',$eess->eess);

        //obtener las actividades
        $results = DB::table('actioodd')
                ->join('cabeza', 'actioodd.id', '=', 'cabeza.actioodd_id')
                ->join('eess', 'cabeza.eess_id', '=', 'eess.id')
                ->where('eess_id', $request->input('ide_eess')) 
                ->orderBy('actioodd.id')
                ->select('cabeza.id as cabeza_id', 'actioodd.id as actioodd_id', 'actioodd.actividad', 'actioodd.prioridad')
                ->get();


        return view('ooddmain', ['results' => $results]);
        
    }

    /*public function ooccselect(Request $request)
    {
        $eess = session('eess');
        if ($eess) {
            return view('ooccselect', compact('eess'));
        } else {
            return redirect()->route('login')->withErrors(['error' => 'Datos no encontrados.']);
        }
    }*/

    public function ooddhoja(Request $request)
    {
        $eessx = $request->input('eessx');  // variable por POST

        if (empty($eessx)) {
            \Log::warning('El valor de eessx está vacío');
            return back()->withErrors(['error' => 'No se seleccionó un órgano desconcentrado.']);
        }

        // Realizamos la primera consulta
        $consulta1 = DB::table('eess as e')
            ->join('oodd as o', 'e.id_oodd', '=', 'o.id')
            ->select('o.oodd', 'e.eess', 'e.codigo')
            ->where('e.codigo', $eessx)
            ->limit(1)
            ->first();

        // Realizamos la segunda consulta
        $consulta2 = DB::table('proyoodd as p')
            ->join('eess as e', 'p.id_eess', '=', 'e.id')
            ->select('p.id', 'p.bloquear')
            ->where('e.codigo', $eessx)
            ->limit(1)
            ->first();

        // Realizamos la tercera consulta
        $consulta3 = DB::table('detalle as d')
            ->leftJoin('fondo as f', 'd.id_fondo', '=', 'f.id')
            ->leftJoin('pofi as p', 'd.id_pofi', '=', 'p.id')
            ->select(
                'd.id', 'd.id_proyoodd', 'd.id_fondo', 
                DB::raw('CASE WHEN d.id_fondo IS NOT NULL THEN f.codigo ELSE NULL END AS fondo_codigo'),
                'd.id_pofi', 'p.codigo AS pofi_codigo', 'p.pofi', 'p.numera', 'p.color', 
                'd.tipo', 'd.estimacion', 'd.enero', 'd.febrero', 'd.marzo', 'd.abril', 
                'd.mayo', 'd.junio', 'd.julio', 'd.agosto', 'd.septiembre', 'd.octubre', 
                'd.noviembre', 'd.diciembre', 'd.total2026', 'd.proy2027', 'd.proy2028', 
                'd.proy2029'
            )
            ->where('d.id_proyoodd', $consulta2->id)
            ->orderBy('d.id_pofi')
            ->get();

        // Ahora pasamos los datos directamente a la vista
        return view('ooddhoja', [
            'eessx' => $eessx,
            'usuario_oodd' => $consulta1->oodd,
            'usuario_eess' => $consulta1->eess,
            'usuario_eess_codigo' => $consulta1->codigo,
            'usuario_idproyoodd' => $consulta2->id,
            'usuario_hojabloqueo' => $consulta2->bloquear,
            'fila' => $consulta3
        ]);
    }


    public function grabarooddhoja(Request $request)//toma valores de cabeza OODD y escribe en cuerpo OODD
    {
        dd($request->all());
        $eess=$request->input('eessx');//necesasio para oodd
        $idex = $request->input('valor_de_idproyoodd');
        $filasF = $request->input('filasF');
        $filasG = $request->input('filasG');
        $detalle = $request->input('detalle');
        $pofitemp;
        $fondotemp;
        
        if(!$idex || !isset($detalle['fData']) || $filasF < 200) {
            return response()->json(['error' => 'Datos imcompletos sobretodo en serie F.'], 400);
        }else{
            //DB::table('detalle')->where('id_proyoodd', $idex)->delete();

            foreach ($detalle['fData'] as $filaF) {
                if($filaF['x']==null || $filaF['x']==""){$fondotemp=null;}
                else{$fondotemp = DB::table('fondo')->where('codigo', $filaF['x'])->limit(1)->value('id');}
                if($filaF['y']==null || $filaF['y']==""){$pofitemp=null;}
                else{$pofitemp = DB::table('pofi')->where('codigo', $filaF['y'])->limit(1)->value('id');}

                if (!$fondotemp || !$pofitemp) {
                \Log::error('No se encontraron los valores de fondo o pofi', [
                    'x' => $filaF['x'],
                    'y' => $filaF['y'],
                    'fondotemp' => $fondotemp,
                    'pofitemp' => $pofitemp,
                ]);
                throw new \Exception('No se encontraron los valores de fondo o pofi.');
            }
                DB::table('detalle')->insert([
                    'id_proyoocc' => null,
                    'id_proyoodd' => $idex,
                    'id_fondo' => $fondotemp,  
                    'id_pofi' => $pofitemp,
                    'tipo' => $filaF['z'], 
                    'estimacion' => $filaF['a'],
                    'enero' => $filaF['b'],
                    'febrero' => $filaF['c'],
                    'marzo' => $filaF['d'],
                    'abril' => $filaF['e'],
                    'mayo' => $filaF['f'],
                    'junio' => $filaF['g'],
                    'julio' => $filaF['h'],
                    'agosto' => $filaF['i'],
                    'septiembre' => $filaF['j'],
                    'octubre' => $filaF['k'],
                    'noviembre' => $filaF['l'],
                    'diciembre' => $filaF['m'],
                    'total2026' => $filaF['n'],
                    'proy2027' => $filaF['o'],
                    'proy2028' => $filaF['p'],
                    'proy2029' => $filaF['q'],
                ]);
            }
        
            if (count($detalle['gData']) > 0) {
                foreach ($detalle['gData'] as $filaG) {
                    if($filaG['x']==null || $filaG['x']==""){$fondotemp=null;}
                    else{$fondotemp = DB::table('fondo')->where('codigo', $filaG['x'])->limit(1)->value('id');}
                    if($filaG['y']==null || $filaG['y']==""){$pofitemp=null;}
                    else{$pofitemp = DB::table('pofi')->where('codigo', $filaG['y'])->limit(1)->value('id');}
                    
                    if (!$fondotemp || !$pofitemp) {
                        throw new \Exception('No se encontraron los valores de fondo o pofi en la serie G.');
                    }

                    DB::table('detalle')->insert([
                        'id_proyoocc' => null,  // Asumimos que esto es NULL
                        'id_proyoodd' => $idex,
                        'id_fondo' => $fondotemp,  
                        'id_pofi' => $pofitemp,
                        'tipo' => $filaG['z'],  
                        'estimacion' => $filaG['a'],
                        'enero' => $filaG['b'],
                        'febrero' => $filaG['c'],
                        'marzo' => $filaG['d'],
                        'abril' => $filaG['e'],
                        'mayo' => $filaG['f'],
                        'junio' => $filaG['g'],
                        'julio' => $filaG['h'],
                        'agosto' => $filaG['i'],
                        'septiembre' => $filaG['j'],
                        'octubre' => $filaG['k'],
                        'noviembre' => $filaG['l'],
                        'diciembre' => $filaG['m'],
                        'total2026' => $filaG['n'],
                        'proy2027' => $filaG['o'],
                        'proy2028' => $filaG['p'],
                        'proy2029' => $filaG['q'],
                    ]);
                }
            }
        }
        return response()->json(['message' => 'Datos guardados correctamente']);
    }

    public function store(Request $request)
    {
        $eess = $request->input('eess'); 
        $valor_de_idproyoodd = $request->input('valor_de_idproyoodd'); 
        $totalFilas = $request->input('totalFilas'); 
        $Data = json_decode($request->input('Data'), true);
        $pofitemp = null; $fondotemp = null;


        DB::beginTransaction();
        try {
            DB::table('detalle')->where('id_proyoodd', $valor_de_idproyoodd)->delete();
            foreach ($Data as $fila) {

                if($fila['x']!=null){$fondotemp = DB::table('fondo')->where('codigo', $fila['x'])->limit(1)->value('id');}
                if($fila['y']!=null){$pofitemp = DB::table('pofi')->where('codigo', $fila['y'])->limit(1)->value('id');}
                DB::table('detalle')->insert([
                    'id_proyoocc' => null,  // Asegúrate de asignar el valor correcto
                    'id_proyoodd' => $valor_de_idproyoodd,  // Asignar el ID de Proyoodd
                    'id_fondo' => $fondotemp,  // Asignar el valor adecuado
                    'id_pofi' => $pofitemp,  // Asignar el valor adecuado
                    'tipo' => $fila['z'], 
                    'estimacion' => $fila['a'],
                    'enero' => $fila['b'],
                    'febrero' => $fila['c'],
                    'marzo' => $fila['d'],
                    'abril' => $fila['e'],
                    'mayo' => $fila['f'],
                    'junio' => $fila['g'],
                    'julio' => $fila['h'],
                    'agosto' => $fila['i'],
                    'septiembre' => $fila['j'],
                    'octubre' => $fila['k'],
                    'noviembre' => $fila['l'],
                    'diciembre' => $fila['m'],
                    'total2026' => $fila['n'],
                    'proy2027' => $fila['o'],
                    'proy2028' => $fila['p'],
                    'proy2029' => $fila['q'],
                ]);
                $pofitemp = null; $fondotemp = null;
            }

            DB::commit();
            $request->merge(['eessx' => $eess]);  // Agregar el valor de eessx al request
            return $this->ooddhoja($request);  
        } catch (\Exception $r) {
            DB::rollback();
            \Log::error("Error al insertar los datos: " . $r->getMessage());
            return back()->withErrors(['error' => 'Hubo un problema al guardar los datos.']);
        }
}


    public function consolida_red(Request $request)
    {
        $eess = session('eess');
        if ($eess) {
            // Pasamos los datos a la vista
            return view('ooddselect', compact('eess'));
        } else {
            // Si no hay datos, puedes redirigir o manejar el error de alguna forma
            return redirect()->route('login')->withErrors(['error' => 'Datos no encontrados.']);
        }
    }

}










