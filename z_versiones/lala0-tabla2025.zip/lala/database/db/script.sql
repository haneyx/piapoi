CREATE DATABASE nombre_base_de_datos CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;
USE nombre_base_de_datos;

CREATE TABLE usuario (
    id INT AUTO_INCREMENT PRIMARY KEY, 
    tipo VARCHAR(1) NOT NULL,
    numera INT NOT NULL,
    cargo VARCHAR(100) NOT NULL,
    usuario VARCHAR(50) NOT NULL,
    clave VARCHAR(50) NOT NULL,
    redirige VARCHAR(20) NOT NULL
);

CREATE TABLE pofi (
    id INT AUTO_INCREMENT PRIMARY KEY, 
    numera INT NOT NULL,
    color INT DEFAULT 0 NOT NULL,
    codigo VARCHAR(10) NOT NULL,
    pofi VARCHAR(50) NOT NULL
);

CREATE TABLE fondo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(6) NOT NULL,
    fondo VARCHAR(60) NOT NULL
);

CREATE TABLE oocc (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numera INT NOT NULL,
    oficina VARCHAR(80) NOT NULL
);

CREATE TABLE oodd (
    id INT AUTO_INCREMENT PRIMARY KEY, 
    numera INT NOT NULL,
    oodd VARCHAR(50) NOT NULL
);
