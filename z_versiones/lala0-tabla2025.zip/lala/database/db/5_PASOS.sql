* el usuario elije la red y luego elije el codigo del establecimiento 12023H0010

1. select id,bloquear de la tabla proyood donde id_esss se compare con el id de la tabla eess y donde sea igual al codigo(de la tabla eess)="12023H0010" de tabla proyoodd

SELECT p.id, p.bloquear
FROM proyoodd p
JOIN eess e ON p.id_eess = e.id  -- Relacionamos las tablas proyoodd y eess por el id_eess y el id
WHERE e.codigo = '12023H0010';  -- Comparamos el código en eess con el valor proporcionado
[login]

* ya se obtuvo el id del proyoodd

2. select id, id_proyoodd, id_fondo(si no es NULL mostrar el codigo de la tabla), id_pofi(aqui se requiere contrastar para obtener el codigo,pofi,numera y color de la tabla pofi), tipo, estimacion, enero, febrero, marzo, abril, mayo, junio, julio, agosto, septiembre,octubre, noviembre, diciembre, total2026, proy2027, proy2028, proy2029 de la tabla detalle (selecciona las tablas y realiza los joins necesarios) donde el proyoodd=202 ordenado por id_pofi

SELECT 
    d.id, 
    d.id_proyoodd, 
    d.id_fondo,
    CASE 
        WHEN d.id_fondo IS NOT NULL THEN f.codigo
        ELSE NULL
    END AS fondo_codigo,
    d.id_pofi,
    p.codigo AS pofi_codigo,
    p.pofi,
    p.numera,
    p.color,
    d.tipo,
    d.estimacion,
    d.enero,
    d.febrero,
    d.marzo,
    d.abril,
    d.mayo,
    d.junio,
    d.julio,
    d.agosto,
    d.septiembre,
    d.octubre,
    d.noviembre,
    d.diciembre,
    d.total2026,
    d.proy2027,
    d.proy2028,
    d.proy2029
FROM detalle d
LEFT JOIN fondo f ON d.id_fondo = f.id
LEFT JOIN pofi p ON d.id_pofi = p.id
WHERE d.id_proyoodd = 202
ORDER BY d.id_pofi;


3. esta seguro de agregar un nuevo fondo financiero para el pofi?
-- EXEC ADD_LINEA_OODD(202,187);