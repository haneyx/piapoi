<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="IngHarold">
    <title>ORGANO DESCONCENTRADO</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/anexo.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
<div class="top">
    <div class="izquierda" style="width:5%;">

        <form method="POST" action="{{ route('ooddmasterselect') }}">
            @csrf
            <button id="volver" type="submit">Volver</button>
        </form>
    </div>
    <div class="titulo" style="float:left;text-align:left;width:95%;">Control Maestro OODD 	<b style="font-size:24px;">&rArr;</b> Establecimiento XY</div>
</div>

<div class="master">
    <table class="m2">
        <thead>
            <tr>
                <th>#</th>
                <th>Código CG.</th>
                <th>Establecimiento de Salud</th>
                <th>Actividades</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <tr>
            <td>1</td>
            <td>12017H0004</td>
            <td>C.M. HUARI PRIMER HOSPITAL</td>
            <td>
                <ul>
                    <li>Nivel 1</li>
                    <li>Nivel II y III</li>
                    <li>Actividades priorizadas de gestion</li>
                </ul>
            </td>
            <td>
                <button id="b1-1" class="edit">Abierto</button>
                <button id="b1-2" class="edit">Abierto</button>
                <button id="b1-3" class="elim">Cerrado</button>
            </td>
        </tr>
        
    </table>
</div>

<div class="footer">
    sistema de programación y formulación presupuestal PIA Y POI 2026
</div>

<script>
    // Seleccionamos todos los botones
    const buttons = document.querySelectorAll('.m2 button');
    
    // Guardamos los textos originales y los colores de fondo
    buttons.forEach(button => {
        const originalText = button.textContent;
        const originalBackgroundColor = button.style.backgroundColor;

        // Evento hover (mouseover y mouseout) para cada botón
        button.addEventListener('mouseover', function() {
            this.textContent = "Intercambiar"; // Cambia el texto a "Intercambiar"
            this.style.backgroundColor = "#ce7b00"; // Cambia el color de fondo al hacer hover
        });

        button.addEventListener('mouseout', function() {
            this.textContent = originalText; // Restaura el texto original cuando el mouse sale
            this.style.backgroundColor = originalBackgroundColor; // Restaura el color original de fondo
        });
    });
</script>

</body>
</html>