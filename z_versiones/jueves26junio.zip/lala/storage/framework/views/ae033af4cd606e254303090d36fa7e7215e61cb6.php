<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="IngHarold">
    <title>ORGANO DESCONCENTRADO</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/login.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div class="todo">
    <div class="container medio">
        <div id="tapa">
            <div id="retorna">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <button class="verbutton" type="submit">Salir</button>
                </form>
            </div>
            <div id="titulo">Administrador de OOCC</div>
            <!--div id="ver">
            </div-->
        </div>
        <div class="largo">
            <form action="<?php echo e(route('ooccmastermain')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label for="establecimiento">Seleccione su centro gestor</label>
                <select name="ide_oficina" id="ide_oficina" required>
                    <?php $__currentLoopData = $oficina; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" 
                                <?php if($item->numera % 10 == 0): ?> disabled <?php endif; ?>>
                            <?php echo e($item->oficina); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit">Continuar</button>
        </form>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\laragon\www\lala\resources\views/ooccmasterselect.blade.php ENDPATH**/ ?>